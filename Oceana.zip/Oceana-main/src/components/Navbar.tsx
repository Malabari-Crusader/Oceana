import { Link, useLocation } from 'react-router-dom';
import { Menu, X, Utensils } from 'lucide-react';
import { useState, useEffect } from 'react';

export default function Navbar() {
  const [isOpen, setIsOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const links = [
    { name: 'Menu', path: '/menu' },
    { name: 'Private Dining', path: '/private-dining' },
    { name: 'Our Story', path: '/story' },
    { name: 'Contact', path: '/contact' },
  ];

  const isActive = (path: string) => location.pathname === path;

  return (
    <header 
      className={`fixed top-0 w-full z-50 transition-all duration-300 ${
        isScrolled ? 'bg-rich-black/95 backdrop-blur-md border-b border-white/10 py-0' : 'bg-transparent py-4'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-20">
          <Link to="/" className="flex items-center gap-3">
            <Utensils className="text-gold w-6 h-6" />
            <span className="font-serif text-2xl font-bold text-white tracking-[0.2em] uppercase">Oceana</span>
          </Link>

          {/* Desktop Menu */}
          <nav className="hidden md:flex items-center gap-8">
            {links.map((link) => (
              <Link
                key={link.name}
                to={link.path}
                className={`font-serif text-lg transition-colors hover:text-gold ${
                  isActive(link.path) ? 'text-gold border-b-2 border-gold pb-1' : 'text-gray-300'
                }`}
              >
                {link.name}
              </Link>
            ))}
            <Link
              to="/reservations"
              className="bg-burgundy hover:bg-burgundy/90 text-white px-6 py-2.5 rounded-sm font-serif text-sm font-bold tracking-widest transition-colors uppercase"
            >
              Reserve Table
            </Link>
          </nav>

          {/* Mobile Menu Button */}
          <button
            className="md:hidden text-gray-300 hover:text-white"
            onClick={() => setIsOpen(!isOpen)}
          >
            {isOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {isOpen && (
        <div className="md:hidden bg-rich-black border-b border-white/10">
          <div className="px-4 pt-2 pb-6 space-y-4 flex flex-col">
            {links.map((link) => (
              <Link
                key={link.name}
                to={link.path}
                onClick={() => setIsOpen(false)}
                className={`font-serif text-xl transition-colors ${
                  isActive(link.path) ? 'text-gold' : 'text-gray-300'
                }`}
              >
                {link.name}
              </Link>
            ))}
            <Link
              to="/reservations"
              onClick={() => setIsOpen(false)}
              className="bg-burgundy text-white px-6 py-3 rounded-sm text-center font-serif font-bold tracking-widest mt-4 uppercase"
            >
              Reserve Table
            </Link>
          </div>
        </div>
      )}
    </header>
  );
}
