import { motion, useScroll, useSpring, useTransform } from 'motion/react';
import { useRef } from 'react';

export default function ScrollTimeline() {
  const containerRef = useRef<HTMLDivElement>(null);
  
  // Track scroll progress through the entire timeline container
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start center", "end center"]
  });

  // Add physics damping so the dot glides smoothly
  const smoothProgress = useSpring(scrollYProgress, {
    stiffness: 100,
    damping: 30,
    restDelta: 0.001
  });

  // Map progress to the dot's vertical position (0% to 100% of the line height)
  const dotY = useTransform(smoothProgress, [0, 1], ["0%", "100%"]);

  // The glow intensity is driven by the raw scroll progress
  // It pulses based on how far you've scrolled
  const glowScale = useTransform(scrollYProgress, 
    [0, 0.2, 0.4, 0.6, 0.8, 1], 
    [1, 1.5, 1, 1.5, 1, 1.5]
  );
  
  const glowOpacity = useTransform(scrollYProgress,
    [0, 0.2, 0.4, 0.6, 0.8, 1],
    [0.3, 0.8, 0.3, 0.8, 0.3, 0.8]
  );

  return (
    <section ref={containerRef} className="py-32 px-4 bg-[#140a0d] relative">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-32 flex flex-col items-center">
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="font-serif text-5xl md:text-6xl text-white flex flex-col sm:flex-row items-center gap-3"
          >
            <span>A Legacy</span>
            <span className="italic relative">
              in Time
              <span className="absolute -bottom-2 left-0 w-full h-1 bg-gold"></span>
            </span>
          </motion.h2>
        </div>

        <div className="relative min-h-[800px]">
          {/* The Track (Background Line) */}
          <div className="hidden md:block absolute left-1/2 top-0 bottom-0 w-px bg-gold/20 -translate-x-1/2"></div>
          
          {/* The Filled Track (Progress Line) */}
          <motion.div 
            className="hidden md:block absolute left-1/2 top-0 w-px bg-gold -translate-x-1/2 origin-top"
            style={{ 
              height: "100%",
              scaleY: smoothProgress 
            }}
          ></motion.div>

          {/* The Gliding Dot */}
          <motion.div 
            className="hidden md:flex absolute left-1/2 -translate-x-1/2 w-4 h-4 items-center justify-center z-20"
            style={{ top: dotY }}
          >
            {/* The Core Dot */}
            <div className="w-3 h-3 rounded-full bg-gold shadow-[0_0_10px_rgba(212,175,55,1)] z-10"></div>
            
            {/* The Pulsing Glow */}
            <motion.div 
              className="absolute w-12 h-12 rounded-full bg-gold/30 blur-md"
              style={{ 
                scale: glowScale,
                opacity: glowOpacity
              }}
            ></motion.div>
          </motion.div>

          <div className="space-y-32 relative z-10">
            {/* Item 1: The Beginning (Threshold ~0.15) */}
            <TimelineItem 
              progress={smoothProgress}
              threshold={0.15}
              year="1994"
              title="The Beginning"
              desc="Oceana opens its doors in the heart of Dammam, a modest 10-table establishment with a bold vision."
              img="https://images.unsplash.com/photo-1514933651103-005eec06c04b?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80"
              align="left"
            />
            
            {/* Item 2: The Expansion (Threshold ~0.5) */}
            <TimelineItem 
              progress={smoothProgress}
              threshold={0.5}
              year="2010"
              title="The Expansion"
              desc="Following international acclaim, the restaurant moves to the Corniche, expanding the team and the menu."
              img="https://images.unsplash.com/photo-1559339352-11d035aa65de?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80"
              align="right"
            />
            
            {/* Item 3: The Jubilee (Threshold ~0.85) */}
            <TimelineItem 
              progress={smoothProgress}
              threshold={0.85}
              year="2024"
              title="The Jubilee"
              desc="Celebrating 30 years of excellence. A new chapter begins with the launch of our fusion academy."
              img="https://images.unsplash.com/photo-1544025162-d76694265947?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80"
              align="left"
            />
          </div>
        </div>
      </div>
    </section>
  );
}

// Sub-component for individual timeline items
function TimelineItem({ progress, threshold, year, title, desc, img, align }: any) {
  const isLeft = align === 'left';
  
  // Calculate when this specific item should reveal based on the dot's progress
  // It starts revealing slightly before the dot reaches it, and finishes as the dot passes
  const opacity = useTransform(
    progress,
    [threshold - 0.2, threshold],
    [0, 1]
  );
  
  // Slide in from the side
  const xOffset = isLeft ? 50 : -50;
  const x = useTransform(
    progress,
    [threshold - 0.2, threshold],
    [xOffset, 0]
  );

  return (
    <div className="relative flex flex-col md:flex-row items-center justify-center w-full group gap-8 md:gap-0">
      {/* Text Side */}
      <div className={`w-full md:w-1/2 flex ${isLeft ? 'md:justify-end md:pr-16' : 'md:justify-start md:pl-16 md:order-2'}`}>
        <motion.div 
          style={{ opacity, x }}
          className={`max-w-md ${isLeft ? 'md:text-right' : 'md:text-left'} text-center`}
        >
          <h3 className="font-serif text-4xl md:text-5xl text-gold mb-2 font-bold">{year}</h3>
          <h4 className="font-serif text-2xl md:text-3xl text-white mb-4 font-bold">{title}</h4>
          <p className="text-gray-300 text-sm md:text-base leading-relaxed">
            {desc}
          </p>
        </motion.div>
      </div>

      {/* Image Side */}
      <div className={`w-full md:w-1/2 flex ${isLeft ? 'md:justify-start md:pl-16 md:order-2' : 'md:justify-end md:pr-16'}`}>
        <motion.div 
          style={{ opacity, x: useTransform(progress, [threshold - 0.2, threshold], [isLeft ? -50 : 50, 0]) }}
          className="relative w-full max-w-md aspect-[4/3] rounded-2xl overflow-hidden group-hover:shadow-[0_0_30px_rgba(212,175,55,0.2)] transition-shadow duration-500"
        >
          <img 
            src={img} 
            alt={title} 
            className="w-full h-full object-cover grayscale hover:grayscale-0 transition-all duration-700 scale-105 hover:scale-100"
          />
          <div className="absolute inset-0 border border-gold/20 rounded-2xl pointer-events-none"></div>
        </motion.div>
      </div>
    </div>
  );
}
