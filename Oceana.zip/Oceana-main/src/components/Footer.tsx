import { Link } from 'react-router-dom';
import { Instagram, Facebook, Twitter, MapPin, Phone, Clock } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-rich-black border-t border-white/10 py-16 mt-auto">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-12">
          {/* Brand */}
          <div className="flex flex-col gap-6">
            <Link to="/" className="flex items-center gap-3">
              <div className="w-8 h-8 bg-gold flex items-center justify-center rounded-sm text-rich-black font-bold text-xl">
                O
              </div>
              <span className="font-serif text-2xl font-bold text-white tracking-wide uppercase">Oceana</span>
            </Link>
            <p className="text-gray-400 text-sm leading-relaxed">
              A culinary landmark in Dammam since 1994. Experience the fusion of Indian, Arabic, and Chinese traditions.
            </p>
            <div className="flex gap-4 text-gray-400">
              <a href="#" className="hover:text-gold transition-colors"><Instagram size={20} /></a>
              <a href="#" className="hover:text-gold transition-colors"><Facebook size={20} /></a>
              <a href="#" className="hover:text-gold transition-colors"><Twitter size={20} /></a>
            </div>
          </div>

          {/* Contact */}
          <div className="flex flex-col gap-4">
            <h4 className="text-gold font-bold tracking-widest uppercase text-sm mb-2">Contact</h4>
            <div className="flex items-start gap-3 text-gray-400 text-sm">
              <Phone size={18} className="shrink-0 mt-0.5 text-burgundy" />
              <p>+966 13 800 9999<br />reservations@oceana.sa</p>
            </div>
          </div>

          {/* Location */}
          <div className="flex flex-col gap-4">
            <h4 className="text-gold font-bold tracking-widest uppercase text-sm mb-2">Location</h4>
            <div className="flex items-start gap-3 text-gray-400 text-sm">
              <MapPin size={18} className="shrink-0 mt-0.5 text-burgundy" />
              <p>King Abdullah Road<br />Corniche, Dammam 32414<br />Saudi Arabia</p>
            </div>
          </div>

          {/* Hours */}
          <div className="flex flex-col gap-4">
            <h4 className="text-gold font-bold tracking-widest uppercase text-sm mb-2">Hours</h4>
            <div className="flex items-start gap-3 text-gray-400 text-sm">
              <Clock size={18} className="shrink-0 mt-0.5 text-burgundy" />
              <div className="flex flex-col gap-1">
                <p><span className="text-white">Mon - Wed:</span> 6pm - 11pm</p>
                <p><span className="text-white">Thu - Fri:</span> 6pm - 1am</p>
                <p><span className="text-white">Sat - Sun:</span> 1pm - 11pm</p>
              </div>
            </div>
          </div>
        </div>
        
        <div className="pt-8 border-t border-white/10 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-sm text-gray-500">
            © {new Date().getFullYear()} Oceana Restaurant. All rights reserved.
          </p>
          <div className="flex gap-6 text-sm font-medium text-gray-500">
            <Link to="#" className="hover:text-gold transition-colors">Privacy Policy</Link>
            <Link to="#" className="hover:text-gold transition-colors">Terms of Service</Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
