import { motion, useScroll, useTransform } from 'motion/react';
import { useRef } from 'react';
import { Link } from 'react-router-dom';
import { ChevronDown, ArrowRight } from 'lucide-react';
import ScrollTimeline from '../components/ScrollTimeline';

export default function Home() {
  const { scrollYProgress } = useScroll();

  return (
    <div className="bg-rich-black text-white selection:bg-burgundy selection:text-white">
      {/* Hero Section */}
      <section className="relative min-h-screen flex flex-col items-center justify-center overflow-hidden">
        {/* Full-bleed background image with dark overlay */}
        <div 
          className="absolute inset-0 z-0 bg-cover bg-center bg-no-repeat"
          style={{ backgroundImage: 'url("https://images.unsplash.com/photo-1514933651103-005eec06c04b?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&q=80")' }}
        >
          <div className="absolute inset-0 bg-gradient-to-b from-rich-black/90 via-rich-black/70 to-rich-black"></div>
        </div>

        <div className="relative z-10 flex flex-col items-center text-center px-4 w-full max-w-5xl mx-auto mt-20">
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="text-gold text-xs md:text-sm font-bold tracking-[0.3em] uppercase mb-6 drop-shadow-[0_2px_4px_rgba(0,0,0,0.8)]"
          >
            Dammam, Saudi Arabia — Est. 1994
          </motion.p>
          
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="font-serif italic text-6xl md:text-8xl lg:text-9xl font-light tracking-tight mb-8 drop-shadow-[0_4px_8px_rgba(0,0,0,0.8)]"
          >
            The Oceana
          </motion.h1>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.6 }}
            className="mb-12"
          >
            <p className="text-xl md:text-3xl font-serif text-white drop-shadow-[0_4px_8px_rgba(0,0,0,0.9)] font-medium tracking-wide">
              Thirty years of culinary theater.<br />
              Where the <span className="text-burgundy italic font-bold drop-shadow-[0_2px_4px_rgba(0,0,0,0.9)]">desert meets the deep</span>.
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.8 }}
          >
            <Link 
              to="/reservations" 
              className="bg-burgundy hover:bg-burgundy/90 text-white px-10 py-4 rounded-full text-sm font-bold tracking-[0.2em] uppercase transition-colors shadow-lg inline-block"
            >
              Reserve a Table
            </Link>
          </motion.div>

          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 1, delay: 1.5 }}
            className="absolute bottom-10 text-gold animate-bounce"
          >
            <ChevronDown size={32} />
          </motion.div>
        </div>
      </section>

      {/* Intro Quote */}
      <section className="py-32 px-4 bg-[#140a0d]">
        <div className="max-w-4xl mx-auto text-center">
          <motion.h2 
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 0.8 }}
            className="font-serif text-3xl md:text-4xl lg:text-5xl leading-relaxed text-gray-200"
          >
            We craft moments, not just meals. A sanctuary in Dammam where global traditions dissolve into a singular experience of luxury.
          </motion.h2>
          <motion.div 
            initial={{ scaleX: 0 }}
            whileInView={{ scaleX: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 1, delay: 0.4 }}
            className="h-px w-24 bg-burgundy mx-auto mt-12 origin-center"
          />
        </div>
      </section>

      {/* Traditions */}
      <TraditionSection 
        num="I"
        title="The East"
        desc="Precision, discipline, and the ancient alchemy of spice. From Kyoto to Bangkok, we source the unsourceable."
        img="https://images.unsplash.com/photo-1552566626-52f8b828add9?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&q=80"
        linkText="DISCOVER THE MENU"
        linkTo="/menu"
        align="left"
      />

      <TraditionSection 
        num="II"
        title="The Subcontinent"
        desc="Technique honed in the fires of India. A dedication to the product, elevated by master craftsmanship."
        img="https://images.unsplash.com/photo-1596040033229-a9821ebd058d?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&q=80"
        linkText="EXPLORE SPICES"
        linkTo="/menu"
        align="right"
      />

      <TraditionSection 
        num="III"
        title="The Middle"
        desc="Rooted in Dammam. The warmth of Saudi hospitality is the canvas upon which we paint. A celebration of our home for 30 years."
        img="https://images.unsplash.com/photo-1541518763669-27fef04b14ea?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&q=80"
        align="center"
      />

      {/* Masters Section */}
      <section className="py-32 px-4 max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row justify-between items-end mb-16 gap-6">
          <div>
            <motion.h2 
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="font-serif text-5xl md:text-7xl text-burgundy mb-2"
            >
              Masters
            </motion.h2>
            <motion.p 
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.2 }}
              className="text-gray-400 font-serif italic text-xl"
            >
              Architects of flavor
            </motion.p>
          </div>
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
          >
            <Link to="/story" className="flex items-center gap-2 text-gold text-sm font-bold tracking-widest uppercase hover:text-white transition-colors">
              Read our story <ArrowRight size={16} />
            </Link>
          </motion.div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 lg:gap-16">
          <MasterCard 
            role="EXECUTIVE CHEF"
            name="Hassan Al-Fayed"
            img="https://images.unsplash.com/photo-1583394838336-acd977736f90?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80"
            delay={0}
          />
          <MasterCard 
            role="SOMMELIER & MANAGER"
            name="Layla Bennett"
            img="https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80"
            delay={0.2}
            className="md:mt-24"
          />
        </div>
      </section>

      {/* Legacy Section */}
      <ScrollTimeline />

      {/* Experience the Legacy CTA */}
      <section className="relative py-32 px-4 bg-rich-black overflow-hidden border-t border-white/5">
        {/* Subtle background texture */}
        <div className="absolute right-0 top-0 bottom-0 w-full md:w-1/2 opacity-10 pointer-events-none">
          <img 
            src="https://images.unsplash.com/photo-1524661135-423995f22d0b?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80" 
            alt="Map texture" 
            className="w-full h-full object-cover mix-blend-overlay" 
          />
        </div>
        
        <div className="relative z-10 max-w-4xl mx-auto text-center flex flex-col items-center">
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="font-serif italic text-5xl md:text-7xl text-white mb-6"
          >
            Experience the Legacy
          </motion.h2>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
            className="text-gray-300 text-lg md:text-xl max-w-2xl mb-12 font-serif"
          >
            Join us for an evening where history is served on a plate. Reservations are highly recommended.
          </motion.p>
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.4 }}
            className="flex flex-col sm:flex-row gap-6"
          >
            <Link 
              to="/reservations" 
              className="bg-burgundy hover:bg-burgundy/90 text-white px-10 py-4 rounded-full text-sm font-bold tracking-[0.2em] uppercase transition-colors shadow-lg"
            >
              Reserve Now
            </Link>
            <Link 
              to="/menu" 
              className="bg-transparent border border-white/30 hover:border-white text-white px-10 py-4 rounded-full text-sm font-bold tracking-[0.2em] uppercase transition-colors"
            >
              View Menu
            </Link>
          </motion.div>
        </div>
      </section>
    </div>
  );
}

function TraditionSection({ num, title, desc, img, linkText, linkTo, align }: any) {
  const ref = useRef(null);
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start end", "end start"]
  });
  
  // Cinematic background animations
  const y = useTransform(scrollYProgress, [0, 1], ["-15%", "15%"]);
  const scale = useTransform(scrollYProgress, [0, 1], [1, 1.15]);
  const overlayOpacity = useTransform(scrollYProgress, [0, 0.5, 1], [0.8, 0.3, 0.8]);

  const alignClass = align === 'left' ? 'items-start text-left' : align === 'right' ? 'items-end text-right' : 'items-center text-center';
  const contentClass = align === 'left' ? 'mr-auto' : align === 'right' ? 'ml-auto' : 'mx-auto';
  const flexJustifyClass = align === 'left' ? 'justify-start' : align === 'right' ? 'justify-end' : 'justify-center';

  // Premium easing curve
  const ease = [0.16, 1, 0.3, 1];

  return (
    <section ref={ref} className="relative h-screen min-h-[600px] flex items-center overflow-hidden">
      <motion.div 
        style={{ y, scale }}
        className="absolute inset-0 w-full h-[130%] -top-[15%] z-0 origin-center"
      >
        <div 
          className="absolute inset-0 bg-cover bg-center"
          style={{ backgroundImage: `url("${img}")` }}
        />
      </motion.div>
      
      {/* Dynamic lighting overlay */}
      <motion.div 
        style={{ opacity: overlayOpacity }}
        className="absolute inset-0 bg-rich-black z-0"
      />
      <div className="absolute inset-0 bg-gradient-to-b from-rich-black via-transparent to-rich-black z-0"></div>

      <div className={`relative z-10 w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col ${alignClass}`}>
        <div className={`max-w-xl ${contentClass}`}>
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-20%" }}
            variants={{
              hidden: {},
              visible: {
                transition: {
                  staggerChildren: 0.2,
                  delayChildren: 0.1,
                }
              }
            }}
          >
            <motion.div 
              variants={{
                hidden: { opacity: 0, y: 30, filter: 'blur(8px)' },
                visible: { opacity: 1, y: 0, filter: 'blur(0px)', transition: { duration: 1.2, ease } }
              }}
              className={`flex items-center gap-4 mb-6 ${flexJustifyClass}`}
            >
              <span className="text-gold text-sm font-bold tracking-[0.2em] uppercase">Tradition</span>
              <span className="h-px w-12 bg-gold"></span>
              <span className="text-gold text-sm font-bold tracking-[0.2em] uppercase">{num}</span>
            </motion.div>

            <motion.h2 
              variants={{
                hidden: { opacity: 0, y: 40, filter: 'blur(8px)' },
                visible: { opacity: 1, y: 0, filter: 'blur(0px)', transition: { duration: 1.4, ease } }
              }}
              className="font-serif text-5xl md:text-7xl lg:text-8xl text-white mb-6 font-light drop-shadow-lg"
            >
              {title}
            </motion.h2>

            <motion.p 
              variants={{
                hidden: { opacity: 0, y: 30 },
                visible: { opacity: 1, y: 0, transition: { duration: 1.2, ease } }
              }}
              className="text-gray-300 text-lg md:text-xl font-serif italic leading-relaxed mb-10 drop-shadow-md"
            >
              {desc}
            </motion.p>

            {linkText && linkTo && (
              <motion.div
                variants={{
                  hidden: { opacity: 0, y: 20 },
                  visible: { opacity: 1, y: 0, transition: { duration: 1, ease } }
                }}
              >
                <Link 
                  to={linkTo} 
                  className="group inline-flex items-center gap-3 text-gold text-sm font-bold tracking-[0.2em] uppercase hover:text-white transition-colors"
                >
                  <span className="border-b border-gold pb-1 group-hover:border-white transition-colors">{linkText}</span>
                  <ArrowRight size={16} className="transform group-hover:translate-x-2 transition-transform" />
                </Link>
              </motion.div>
            )}
          </motion.div>
        </div>
      </div>
    </section>
  );
}

function MasterCard({ role, name, img, delay, className = "" }: any) {
  return (
    <motion.div 
      initial={{ opacity: 0, y: 50 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-100px" }}
      transition={{ duration: 0.8, delay }}
      className={`relative group overflow-hidden bg-white/5 ${className}`}
    >
      <div className="aspect-[4/5] overflow-hidden">
        <img 
          src={img} 
          alt={name} 
          className="w-full h-full object-cover grayscale opacity-80 group-hover:grayscale-0 group-hover:opacity-100 group-hover:scale-105 transition-all duration-700"
        />
      </div>
      <div className="absolute inset-0 bg-gradient-to-t from-rich-black via-transparent to-transparent opacity-80"></div>
      <div className="absolute bottom-0 left-0 p-8">
        <p className="text-gold text-xs font-bold tracking-[0.2em] uppercase mb-2">{role}</p>
        <h3 className="font-serif italic text-3xl md:text-4xl text-white">{name}</h3>
      </div>
    </motion.div>
  );
}

function TimelineItemWithImage({ year, title, desc, img, align }: any) {
  const isLeft = align === 'left';
  
  return (
    <div className="relative flex flex-col md:flex-row items-center justify-center w-full group gap-8 md:gap-0">
      {/* Center Line Node (Desktop) */}
      <div className="hidden md:block absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-4 h-4 rounded-full border-2 border-gold bg-rich-black z-10 transition-colors group-hover:bg-gold shadow-[0_0_15px_rgba(212,175,55,0.5)]"></div>
      
      {/* Text Side */}
      <div className={`w-full md:w-1/2 flex ${isLeft ? 'md:justify-end md:pr-16' : 'md:justify-start md:pl-16 md:order-2'}`}>
        <motion.div 
          initial={{ opacity: 0, x: isLeft ? 50 : -50 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.8 }}
          className={`max-w-md ${isLeft ? 'md:text-right' : 'md:text-left'} text-center`}
        >
          <h3 className="font-serif text-4xl md:text-5xl text-gold mb-2 font-bold">{year}</h3>
          <h4 className="font-serif text-2xl md:text-3xl text-white mb-4 font-bold">{title}</h4>
          <p className="text-gray-300 text-sm md:text-base leading-relaxed">
            {desc}
          </p>
        </motion.div>
      </div>

      {/* Image Side */}
      <div className={`w-full md:w-1/2 flex ${isLeft ? 'md:justify-start md:pl-16 md:order-2' : 'md:justify-end md:pr-16'}`}>
        <motion.div 
          initial={{ opacity: 0, scale: 0.9 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.8 }}
          className="w-full max-w-md rounded-xl overflow-hidden aspect-[16/9] border border-white/10 shadow-2xl"
        >
          <img 
            src={img} 
            alt={title} 
            className="w-full h-full object-cover opacity-80 group-hover:opacity-100 group-hover:scale-105 transition-all duration-700" 
          />
        </motion.div>
      </div>
    </div>
  );
}

