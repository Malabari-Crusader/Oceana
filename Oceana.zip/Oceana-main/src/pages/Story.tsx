import { Flame, Coffee, Utensils, MapPin } from 'lucide-react';

export default function Story() {
  return (
    <div className="flex flex-col gap-12 pb-16 pt-32">
      {/* Hero Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-8">
        <div className="relative h-[50vh] min-h-[400px] flex items-center justify-center overflow-hidden rounded-3xl">
          <div 
            className="absolute inset-0 bg-cover bg-center"
            style={{ backgroundImage: 'url("https://images.unsplash.com/photo-1514933651103-005eec06c04b?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&q=80")' }}
          >
            <div className="absolute inset-0 bg-gradient-to-b from-rich-black/90 via-rich-black/60 to-rich-black/90"></div>
          </div>
          
          <div className="relative z-10 text-center px-4 max-w-3xl mx-auto flex flex-col gap-6">
            <p className="text-gold font-medium tracking-widest uppercase text-sm mb-4">The Oceana Journey</p>
            <h1 className="font-serif italic text-5xl md:text-7xl font-bold text-white tracking-tight drop-shadow-lg">
              Our Story & Culture
            </h1>
            <p className="text-xl md:text-2xl text-gray-200 font-serif italic leading-relaxed drop-shadow-md">
              Where the spices of India, the warmth of Arabia, and the precision of China converge in a symphony of flavors.
            </p>
          </div>
        </div>
      </section>

      {/* Three Pillars */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {[
            {
              title: 'The Spirit of India',
              desc: 'Rich heritage translated through vibrant spices, ancient recipes, and intricate flavors that dance on the palate like a colorful festival.',
              icon: Flame,
              color: 'text-burgundy',
              bg: 'bg-burgundy/20',
              img: 'https://images.unsplash.com/photo-1596040033229-a9821ebd058d?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'
            },
            {
              title: 'The Heart of Arabia',
              desc: 'Legendary hospitality embodied in every dish. Warmth, generosity, and centuries of culinary traditions shared around a welcoming table.',
              icon: Coffee,
              color: 'text-gold',
              bg: 'bg-gold/20',
              img: 'https://images.unsplash.com/photo-1541518763669-27fef04b14ea?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'
            },
            {
              title: 'The Soul of China',
              desc: 'A dedication to balance and precision. Delicate flavors, meticulous preparation, and a deep respect for natural ingredients.',
              icon: Utensils,
              color: 'text-emerald-500',
              bg: 'bg-emerald-500/20',
              img: 'https://images.unsplash.com/photo-1563245372-f21724e3856d?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'
            }
          ].map((item) => (
            <div key={item.title} className="group relative rounded-2xl overflow-hidden aspect-[3/4] flex flex-col justify-end transition-transform duration-300 hover:-translate-y-2">
              <div 
                className="absolute inset-0 bg-cover bg-center transition-transform duration-700 group-hover:scale-105"
                style={{ backgroundImage: `url("${item.img}")` }}
              ></div>
              <div className="absolute inset-0 bg-gradient-to-t from-rich-black via-rich-black/60 to-transparent"></div>
              
              <div className="relative z-10 p-8 flex flex-col gap-4">
                <div className={`w-12 h-12 rounded-full ${item.bg} flex items-center justify-center backdrop-blur-sm mb-2 ${item.color} border border-white/10`}>
                  <item.icon size={24} />
                </div>
                <h3 className="text-white font-serif text-3xl font-bold leading-tight">{item.title}</h3>
                <p className="text-gray-300 font-serif italic text-lg leading-relaxed line-clamp-3">
                  {item.desc}
                </p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Quote Section */}
      <section className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="bg-white/5 border border-white/10 rounded-3xl p-12 text-center flex flex-col items-center gap-8 relative overflow-hidden">
          <div className="absolute top-0 right-0 w-64 h-64 bg-burgundy/10 rounded-full blur-3xl -mr-20 -mt-20"></div>
          <div className="absolute bottom-0 left-0 w-64 h-64 bg-gold/10 rounded-full blur-3xl -ml-20 -mb-20"></div>
          
          <div className="relative z-10 flex flex-col items-center gap-6">
            <Utensils className="text-gold w-12 h-12" />
            <h2 className="text-3xl md:text-4xl font-serif font-bold text-white">A Culinary Tapestry</h2>
            <p className="text-xl md:text-2xl font-serif italic text-gray-300 leading-relaxed max-w-3xl">
              "At Oceana, we don't just cook food; we weave stories. Our journey began with a vision to create a unique dining sanctuary in the heart of Dammam. We invite you to experience a menu that transcends borders, celebrating the distinct yet harmonious souls of three magnificent cultures."
            </p>
            <p className="text-sm font-medium text-gray-500 uppercase tracking-widest mt-4">
              — The Oceana Family
            </p>
          </div>
        </div>
      </section>

      {/* Map Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="flex items-center gap-3 mb-8">
          <MapPin className="text-gold w-8 h-8" />
          <h2 className="text-3xl font-serif font-bold text-white">Find Us in Dammam</h2>
        </div>
        
        <div className="w-full h-[400px] rounded-3xl overflow-hidden relative border border-white/10">
          <img 
            src="https://images.unsplash.com/photo-1524661135-423995f22d0b?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&q=80" 
            alt="Map" 
            className="w-full h-full object-cover opacity-50 sepia-[.3] hue-rotate-[-30deg]"
          />
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="bg-rich-black/90 backdrop-blur-md p-6 rounded-2xl border border-white/10 shadow-2xl flex items-start gap-4 max-w-sm m-4">
              <div className="w-12 h-12 rounded-full bg-burgundy/20 flex items-center justify-center flex-shrink-0">
                <Utensils className="text-burgundy w-6 h-6" />
              </div>
              <div>
                <h4 className="font-bold text-white text-lg mb-1">Oceana Restaurant</h4>
                <p className="text-sm text-gray-400 leading-relaxed">
                  Corniche Road, Dammam<br/>
                  Kingdom of Saudi Arabia
                </p>
                <a href="#" className="inline-block mt-3 text-gold text-sm font-medium hover:underline">
                  Get Directions
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
