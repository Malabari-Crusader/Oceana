import { Link } from 'react-router-dom';

export default function PrivateDining() {
  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-20 pt-32 text-center">
      <h1 className="font-serif text-5xl font-bold text-gold mb-6">Private Dining</h1>
      <p className="text-gray-300 text-lg mb-12 max-w-2xl mx-auto">
        Experience Oceana in an exclusive setting. Our private dining rooms offer the perfect atmosphere for intimate gatherings, corporate events, and special celebrations.
      </p>
      <Link
        to="/reservations"
        className="bg-burgundy hover:bg-burgundy/90 text-white px-8 py-4 rounded-sm text-sm font-bold tracking-[0.2em] uppercase transition-colors inline-block"
      >
        Inquire Now
      </Link>
    </div>
  );
}
