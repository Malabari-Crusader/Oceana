import { useState } from 'react';
import { ChevronDown, ChevronUp } from 'lucide-react';
import { menuData } from '../data/menuData';

export default function Menu() {
  const [expandedCategories, setExpandedCategories] = useState<Record<string, boolean>>({});

  const toggleCategory = (id: string) => {
    setExpandedCategories(prev => ({ ...prev, [id]: !prev[id] }));
  };

  return (
    <div className="bg-[#140a0d] min-h-screen pb-20">
      {/* Header Section */}
      <div className="relative pt-48 pb-32 mb-20 flex items-center justify-center overflow-hidden">
        {/* Background Image */}
        <div 
          className="absolute inset-0 z-0"
          style={{
            backgroundImage: 'url("https://images.unsplash.com/photo-1559339352-11d035aa65de?q=80&w=2000&auto=format&fit=crop")',
            backgroundPosition: 'center',
            backgroundSize: 'cover',
            backgroundAttachment: 'fixed'
          }}
        >
          {/* Overlay */}
          <div className="absolute inset-0 bg-[#140a0d]/70 backdrop-blur-[2px]"></div>
          <div className="absolute inset-0 bg-gradient-to-b from-[#140a0d]/40 via-[#140a0d]/60 to-[#140a0d]"></div>
        </div>

        <div className="relative z-10 max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="font-serif text-5xl md:text-7xl font-bold text-gold mb-6 drop-shadow-2xl">A Culinary Journey</h1>
          <p className="text-gray-200 text-lg md:text-xl font-sans max-w-2xl mx-auto leading-relaxed drop-shadow-lg">
            Embark on an epicurean adventure across three distinct and
            masterful traditions, curated for the most discerning palate.
          </p>
        </div>
      </div>

      {/* Menu Categories */}
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col gap-16">
        {menuData.map((category, index) => (
          <div 
            key={category.id}
            className="relative border border-[#332211] rounded-xl p-8 md:p-12 overflow-hidden bg-[#1a0d11]"
          >
            {/* Subtle Grid Background */}
            <div 
              className="absolute inset-0 pointer-events-none opacity-[0.03]" 
              style={{ 
                backgroundImage: 'linear-gradient(to right, #ffffff 1px, transparent 1px), linear-gradient(to bottom, #ffffff 1px, transparent 1px)', 
                backgroundSize: '24px 24px' 
              }}
            ></div>

            {/* Category Header */}
            <div className="flex justify-between items-start mb-12 relative z-10">
              <div>
                <h2 className="text-3xl md:text-4xl font-serif text-gold mb-2">{category.title}</h2>
                <p className="text-gray-400 font-serif italic text-lg">{category.subtitle}</p>
              </div>
              <category.icon className="text-gold/60 w-8 h-8 flex-shrink-0 ml-4" />
            </div>

            {/* Category Content Grid */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 relative z-10 items-start">
              {/* Items List */}
              <div className={`flex flex-col gap-10 ${index % 2 === 1 ? 'lg:order-2' : 'lg:order-1'}`}>
                {category.items.map((item, iIdx) => (
                  <div key={iIdx} className="group">
                    <div className="flex justify-between items-start mb-3 gap-4">
                      <h3 className="text-xl font-serif text-white group-hover:text-gold transition-colors">{item.name}</h3>
                      <span className="text-gold font-sans font-bold text-sm whitespace-nowrap mt-1 tracking-wide">{item.price}</span>
                    </div>
                    <p className="text-gray-400 text-sm leading-relaxed font-sans">{item.desc}</p>
                  </div>
                ))}
              </div>

              {/* Category Image */}
              <div className={`relative h-[400px] lg:h-[600px] rounded-lg overflow-hidden border border-[#332211] sticky top-32 ${index % 2 === 1 ? 'lg:order-1' : 'lg:order-2'}`}>
                <img 
                  src={category.image} 
                  alt={category.title}
                  className="absolute inset-0 w-full h-full object-cover hover:scale-105 transition-transform duration-700"
                />
              </div>
            </div>

            {/* Additional Items Expandable Section */}
            {category.additional && category.additional.length > 0 && (
              <div className="mt-12 pt-8 border-t border-white/10 relative z-10">
                <button
                  onClick={() => toggleCategory(category.id)}
                  className="flex items-center gap-2 text-gold hover:text-white transition-colors font-serif text-lg"
                >
                  {expandedCategories[category.id] ? <ChevronUp size={20} /> : <ChevronDown size={20} />}
                  {expandedCategories[category.id] ? 'Hide Additional Items' : 'View Additional Items'}
                </button>

                {expandedCategories[category.id] && (
                  <div className="mt-8 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                    {category.additional.map((group, gIdx) => (
                      <div key={gIdx}>
                        <h4 className="text-white font-serif text-xl mb-4 border-b border-white/10 pb-2">{group.group}</h4>
                        <ul className="space-y-3">
                          {group.items.map((item, iIdx) => (
                            <li key={iIdx} className="flex justify-between items-center text-sm">
                              <span className="text-gray-300">{item.name}</span>
                              <span className="text-gold font-sans">{item.price}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Footer Note */}
      <div className="max-w-4xl mx-auto px-4 text-center mt-24 text-gray-500 text-sm font-sans space-y-2">
        <p>Prices are in Saudi Riyal (SAR) and inclusive of 15% VAT.</p>
        <p>Please inform your server of any dietary requirements or allergies.</p>
      </div>
    </div>
  );
}
