import { useState } from 'react';
import { Calendar, Clock, Users, Cake, Heart, Briefcase, PartyPopper } from 'lucide-react';

export default function Reservations() {
  const today = new Date();
  const [currentDate, setCurrentDate] = useState(new Date(today.getFullYear(), today.getMonth(), 1));
  
  const currentMonth = currentDate.toLocaleString('default', { month: 'long' });
  const currentYear = currentDate.getFullYear();
  const daysInMonth = new Date(currentYear, currentDate.getMonth() + 1, 0).getDate();
  const firstDayOfMonth = new Date(currentYear, currentDate.getMonth(), 1).getDay();

  const [selectedDate, setSelectedDate] = useState(today.getDate());
  const [selectedMonth, setSelectedMonth] = useState(today.getMonth());
  const [selectedYear, setSelectedYear] = useState(today.getFullYear());
  
  const [selectedTime, setSelectedTime] = useState('7:30 PM');
  const [guests, setGuests] = useState(2);
  const [occasion, setOccasion] = useState('Birthday');
  const [contact, setContact] = useState({ name: '', email: '', phone: '' });

  const times = ['6:00 PM', '6:30 PM', '7:00 PM', '7:30 PM', '8:00 PM', '8:30 PM', '9:00 PM'];
  const occasions = [
    { name: 'Birthday', icon: Cake },
    { name: 'Anniversary', icon: Heart },
    { name: 'Business', icon: Briefcase },
    { name: 'Other', icon: PartyPopper },
  ];

  const handlePrevMonth = () => {
    setCurrentDate(new Date(currentYear, currentDate.getMonth() - 1, 1));
  };

  const handleNextMonth = () => {
    setCurrentDate(new Date(currentYear, currentDate.getMonth() + 1, 1));
  };

  const handleDateSelect = (day: number) => {
    setSelectedDate(day);
    setSelectedMonth(currentDate.getMonth());
    setSelectedYear(currentYear);
  };

  const displaySelectedMonth = new Date(selectedYear, selectedMonth, 1).toLocaleString('default', { month: 'long' });

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12 pt-32">
      <div className="flex flex-col gap-4 mb-12">
        <h1 className="font-serif text-5xl font-bold text-gold">Reserve Your Table</h1>
        <p className="text-gray-300 text-lg">Experience the finest fusion of Indian, Arabic, and Chinese cuisines in an upscale setting.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
        {/* Left Column */}
        <div className="lg:col-span-7 flex flex-col gap-8">
          
          {/* Date Picker */}
          <div className="bg-white/5 border border-white/10 rounded-2xl p-6">
            <h3 className="font-bold text-white uppercase tracking-wide mb-6">Select Date</h3>
            <div className="flex items-center justify-between mb-4">
              <button onClick={handlePrevMonth} className="text-gray-400 hover:text-white">&lt;</button>
              <span className="font-bold text-lg text-white">{currentMonth} {currentYear}</span>
              <button onClick={handleNextMonth} className="text-gray-400 hover:text-white">&gt;</button>
            </div>
            <div className="grid grid-cols-7 gap-y-2 text-center">
              {['SU', 'MO', 'TU', 'WE', 'TH', 'FR', 'SA'].map(day => (
                <div key={day} className="text-xs font-bold text-gray-500 pb-2">{day}</div>
              ))}
              {Array.from({ length: firstDayOfMonth }).map((_, i) => (
                <div key={`empty-${i}`} className="h-10"></div>
              ))}
              {Array.from({ length: daysInMonth }, (_, i) => i + 1).map(day => {
                const isSelected = selectedDate === day && selectedMonth === currentDate.getMonth() && selectedYear === currentYear;
                return (
                  <button
                    key={day}
                    onClick={() => handleDateSelect(day)}
                    className={`h-10 w-full flex items-center justify-center text-sm font-medium rounded-full transition-colors ${
                      isSelected
                        ? 'bg-burgundy text-white font-bold shadow-lg' 
                        : 'text-gray-300 hover:bg-white/10'
                    }`}
                  >
                    {day}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Time Picker */}
          <div className="bg-white/5 border border-white/10 rounded-2xl p-6">
            <h3 className="font-bold text-white uppercase tracking-wide mb-6">Select Time</h3>
            <div className="flex flex-wrap gap-3">
              {times.map(time => (
                <button
                  key={time}
                  onClick={() => setSelectedTime(time)}
                  className={`flex h-10 items-center justify-center rounded-full px-5 transition-colors ${
                    selectedTime === time
                      ? 'bg-burgundy text-white font-bold shadow-md'
                      : 'bg-white/5 text-gray-300 hover:bg-white/10'
                  }`}
                >
                  <span className="text-sm">{time}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Party Size */}
          <div className="bg-white/5 border border-white/10 rounded-2xl p-6">
            <h3 className="font-bold text-white uppercase tracking-wide mb-6">Party Size</h3>
            <div className="flex items-center gap-6">
              <button 
                onClick={() => setGuests(Math.max(1, guests - 1))}
                className="w-10 h-10 rounded-full border border-white/20 flex items-center justify-center text-gray-300 hover:bg-white/10"
              >
                -
              </button>
              <span className="text-2xl font-bold w-8 text-center text-white">{guests}</span>
              <button 
                onClick={() => setGuests(guests + 1)}
                className="w-10 h-10 rounded-full border border-white/20 flex items-center justify-center text-gray-300 hover:bg-white/10"
              >
                +
              </button>
              <span className="text-sm text-gray-400 ml-2">Guests</span>
            </div>
          </div>
          {/* Contact Details */}
          <div className="bg-white/5 border border-white/10 rounded-2xl p-6">
            <h3 className="font-bold text-white uppercase tracking-wide mb-6">Contact Details</h3>
            <div className="flex flex-col gap-4">
              <input 
                type="text" 
                placeholder="Full Name" 
                value={contact.name}
                onChange={(e) => setContact({...contact, name: e.target.value})}
                className="w-full rounded-xl border border-white/10 bg-white/5 p-4 text-sm text-white placeholder-gray-500 focus:outline-none focus:border-gold focus:ring-1 focus:ring-gold"
              />
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <input 
                  type="email" 
                  placeholder="Email Address" 
                  value={contact.email}
                  onChange={(e) => setContact({...contact, email: e.target.value})}
                  className="w-full rounded-xl border border-white/10 bg-white/5 p-4 text-sm text-white placeholder-gray-500 focus:outline-none focus:border-gold focus:ring-1 focus:ring-gold"
                />
                <input 
                  type="tel" 
                  placeholder="Phone Number" 
                  value={contact.phone}
                  onChange={(e) => setContact({...contact, phone: e.target.value})}
                  className="w-full rounded-xl border border-white/10 bg-white/5 p-4 text-sm text-white placeholder-gray-500 focus:outline-none focus:border-gold focus:ring-1 focus:ring-gold"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Right Column */}
        <div className="lg:col-span-5 flex flex-col gap-8">
          
          {/* Special Occasion */}
          <div className="bg-white/5 border border-white/10 rounded-2xl p-6">
            <h3 className="font-bold text-white uppercase tracking-wide mb-2">Special Occasion</h3>
            <p className="text-sm text-gray-400 mb-6">Let us know if you're celebrating something special.</p>
            <div className="grid grid-cols-2 gap-4">
              {occasions.map(occ => (
                <button
                  key={occ.name}
                  onClick={() => setOccasion(occ.name)}
                  className={`flex flex-col items-center justify-center gap-3 p-4 rounded-xl border transition-all ${
                    occasion === occ.name
                      ? 'border-gold bg-gold/10 text-gold'
                      : 'border-white/10 text-gray-400 hover:border-gold/50 hover:bg-gold/5'
                  }`}
                >
                  <occ.icon size={28} />
                  <span className="text-sm font-medium">{occ.name}</span>
                </button>
              ))}
            </div>
            <textarea 
              className="w-full mt-6 rounded-xl border border-white/10 bg-white/5 p-4 text-sm text-white placeholder-gray-500 focus:outline-none focus:border-gold focus:ring-1 focus:ring-gold"
              placeholder="Any special requests? (Optional)"
              rows={3}
            ></textarea>
          </div>

          {/* Booking Summary */}
          <div className="bg-burgundy/10 border border-burgundy/30 rounded-2xl p-6">
            <h3 className="font-bold text-gold uppercase tracking-wide mb-6 border-b border-burgundy/30 pb-4">Booking Summary</h3>
            <div className="flex flex-col gap-4 mb-8">
              <div className="flex justify-between items-center text-gray-300">
                <span className="flex items-center gap-3"><Calendar size={18} /> Date</span>
                <span className="font-bold text-white">{displaySelectedMonth.substring(0, 3)} {selectedDate}, {selectedYear}</span>
              </div>
              <div className="flex justify-between items-center text-gray-300">
                <span className="flex items-center gap-3"><Clock size={18} /> Time</span>
                <span className="font-bold text-white">{selectedTime}</span>
              </div>
              <div className="flex justify-between items-center text-gray-300">
                <span className="flex items-center gap-3"><Users size={18} /> Guests</span>
                <span className="font-bold text-white">{guests} People</span>
              </div>
              <div className="flex justify-between items-center text-gray-300">
                <span className="flex items-center gap-3"><Cake size={18} /> Occasion</span>
                <span className="font-bold text-gold">{occasion}</span>
              </div>
            </div>
            <button className="w-full bg-burgundy hover:bg-burgundy/90 text-white font-bold uppercase tracking-widest py-4 px-6 rounded-xl shadow-lg transition-transform hover:-translate-y-1">
              Confirm Booking
            </button>
            <p className="text-xs text-center text-gray-500 mt-4">By confirming, you agree to our reservation policy.</p>
          </div>

        </div>
      </div>
    </div>
  );
}
